// import 'package:flutter/material.dart';
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:firebase_auth/firebase_auth.dart';
//
// class Messenger extends StatefulWidget {
//   final String currentUserId;
//   final String chatUserId = "CwXqp7gKtPWUmi9VNJXO0GX7S0G2";
//
//   Messenger({required this.currentUserId});
//
//   @override
//   _MessengerState createState() => _MessengerState();
// }
//
// class _MessengerState extends State<Messenger> {
//   final FirebaseFirestore _firestore = FirebaseFirestore.instance;
//   CollectionReference? _chatCollection;
//   FirebaseAuth _auth = FirebaseAuth.instance;
//
//   List<Map<String, dynamic>> messages = [];
//   TextEditingController messageController = TextEditingController();
//
//   @override
//   void initState() {
//     super.initState();
//     // Store all chat data in a single "chats" collection
//     _chatCollection = _firestore.collection('chats');
//     _subscribeToChatMessages();
//   }
//
//   void _subscribeToChatMessages() {
//     // Query the "chats" collection for messages from the admin (currentUserId) and the specific user
//     Query chatQuery = _chatCollection!
//         .where('senderId', whereIn: [widget.currentUserId, widget.chatUserId])
//         .orderBy('timestamp');
//
//     chatQuery.snapshots().listen((snapshot) {
//       setState(() {
//         messages = snapshot.docs.map((doc) => doc.data() as Map<String, dynamic>).toList();
//       });
//     });
//   }
//
//   void _sendMessage() {
//     String message = messageController.text;
//     if (message.isNotEmpty) {
//       _chatCollection!.add({
//         'senderId': widget.currentUserId,
//         'receiverId': widget.chatUserId,
//         'text': message,
//         'timestamp': FieldValue.serverTimestamp(),
//       });
//       messageController.clear();
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Chat with User'),
//       ),
//       body: Column(
//         children: [
//           Expanded(
//             child: ListView.builder(
//               itemCount: messages.length,
//               itemBuilder: (context, index) {
//                 final message = messages[index];
//                 return ListTile(
//                   title: Text(message['text'] as String),
//                   subtitle: Text(message['senderId'] == widget.currentUserId
//                       ? 'You'
//                       : message['senderId'] as String),
//                 );
//               },
//             ),
//           ),
//           Padding(
//             padding: const EdgeInsets.all(8.0),
//             child: Row(
//               children: [
//                 Expanded(
//                   child: TextField(
//                     controller: messageController,
//                     decoration: InputDecoration(
//                       hintText: 'Type a message...',
//                     ),
//                   ),
//                 ),
//                 IconButton(
//                   icon: Icon(Icons.send),
//                   onPressed: _sendMessage,
//                 ),
//               ],
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }
//





import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class Messenger extends StatefulWidget {
  final String currentUserId;
  final String chatUserId = "CwXqp7gKtPWUmi9VNJXO0GX7S0G2";

  // ChatScreen({required this.currentUserId, required this.chatUserId});
  Messenger({required this.currentUserId, required chatUserId});

  @override
  _MessengerState createState() => _MessengerState();
}

class _MessengerState extends State<Messenger> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  CollectionReference? _chatCollection;
  FirebaseAuth _auth = FirebaseAuth.instance;

  List<Map<String, dynamic>> messages = [];
  TextEditingController messageController = TextEditingController();

  @override
  // void initState() {
  //   super.initState();
  //   _chatCollection = _firestore.collection('chats_${widget.currentUserId}_${widget.chatUserId}');
  //   _subscribeToChatMessages();
  // }
  // void initState() {
  //   super.initState();
  //   // Store all chat data in a collection named "chats"
  //   _chatCollection = _firestore.collection('chats').doc(widget.currentUserId).collection('chats_${widget.chatUserId}');
  //
  //   _subscribeToChatMessages();
  // }
  void initState() {
    super.initState();

    // Create a collection reference for the chat room based on currentUserId
    _chatCollection = _firestore.collection('chats').doc(widget.currentUserId).collection('messages');

    _subscribeToChatMessages();
  }


  void _subscribeToChatMessages() {
    _chatCollection!.orderBy('timestamp').snapshots().listen((snapshot) {
      setState(() {
        messages = snapshot.docs.map((doc) => doc.data() as Map<String, dynamic>).toList();
      });
    });
  }

  void _sendMessage() {
    String message = messageController.text;
    if (message.isNotEmpty) {
      _chatCollection!.add({
        'senderId': widget.currentUserId,
        'text': message,
        'timestamp': FieldValue.serverTimestamp(),
      });
      messageController.clear();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Chat with User'),
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              itemCount: messages.length,
              itemBuilder: (context, index) {
                final message = messages[index];
                return ListTile(
                  title: Text(message['text'] as String),
                  subtitle: Text(message['senderId'] as String),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: messageController,
                    decoration: InputDecoration(
                      hintText: 'Type a message...',
                    ),
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.send),
                  onPressed: _sendMessage,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
